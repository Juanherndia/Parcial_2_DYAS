const express = require("express");
const cors = require("cors");
const app = express();
const PORT = process.env.PORT || 3002;

app.use(cors());

app.get("/info", (req, res) => {
  res.json({
    service: "B",
    message: "Hola desde Service B",
    timestamp: new Date().toISOString(),
    features: ["places", "geo"],
  });
});

// Devuelve algunos puntos geográficos (lat, lng, name)
app.get("/places", (req, res) => {
  const places = [
    { id: 1, name: "Plaza Central", lat: 40.416775, lng: -3.70379 },
    { id: 2, name: "Parque Norte", lat: 40.42, lng: -3.71 },
    { id: 3, name: "Museo PoC", lat: 40.415, lng: -3.695 },
  ];
  res.json({ items: places, generatedAt: new Date().toISOString() });
});

app.listen(PORT, () => {
  console.log(`Service B escuchando en http://localhost:${PORT}`);
});
