# Informe PoC: Microservicios + API Gateway (con mapa)

Ey parce, esto es un informe corto y claro para que cualquier persona del equipo (o usted, si está probando desde su computador) pueda levantar y entender el PoC que armé: dos microservicios que se comunican entre sí a través de un API Gateway, y un frontend sencillo que muestra los resultados en un mapa.

Resumen del repo

- gateway/ (puerto 3000): sirve el frontend (archivos estáticos) y actúa como API Gateway, proxyando rutas a los servicios.
- service-a/ (puerto 3001): service A — expone `/info` y `/call-b`. El endpoint `/call-b` llama a Service B y devuelve los datos enriquecidos.
- service-b/ (puerto 3002): service B — expone `/info` y `/places` (devuelve una lista de lugares con lat/lng).

Requisitos

- Node.js (recomendado >=16)
- PowerShell (si vas a seguir las instrucciones para Windows)

Qué hace este PoC

- El Gateway recibe las peticiones del frontend y las reenvía a los servicios adecuados.
- El frontend usa Leaflet + OpenStreetMap para mostrar los lugares que devuelve Service B.
- Demo de flujo: el botón "Service A -> B" en el frontend hace una petición al Gateway → Gateway la envía a Service A → Service A hace una petición a Service B → Service B devuelve places → Service A calcula un centro y devuelve todo al frontend → el frontend pinta los marcadores en el mapa.

Instrucciones (forma rápida — un comando para todo)
Si quieres levantar todo en una sola terminal (recomendado para pruebas rápidas), en la raíz del repo ejecuta:

```powershell
cd "C:\Users\herma\OneDrive\Escritorio\Juegoooo"
npm install
npm run dev
```

Ese `npm run dev` usa `concurrently` para ejecutar `npm start` en `service-b`, `service-a` y `gateway` al mismo tiempo. Si algo no arranca por conflicto de puertos, revisa el apartado de troubleshooting abajo.

Instrucciones (forma manual — tres terminales separadas)

```powershell
# Terminal 1 - Service B
cd "C:\Users\herma\OneDrive\Escritorio\Juegoooo\service-b"
npm install
npm start

# Terminal 2 - Service A
cd "C:\Users\herma\OneDrive\Escritorio\Juegoooo\service-a"
npm install
npm start

# Terminal 3 - Gateway (frontend)
cd "C:\Users\herma\OneDrive\Escritorio\Juegoooo\gateway"
npm install
npm start
```

Abrir en el navegador: http://localhost:3000

Endpoints útiles (para debug)

- Gateway (proxy):
  - http://localhost:3000/api/service-a/info (va a service-a)
  - http://localhost:3000/api/service-a/call-b (service-a llama a service-b)
  - http://localhost:3000/api/service-b/places (va a service-b)
- Directo (si prefieres evitar el gateway durante debug):
  - http://localhost:3001/info
  - http://localhost:3002/info
  - http://localhost:3002/places

Problemas comunes y soluciones (manejables)

- Error EADDRINUSE (puerto en uso): significa que otro proceso ya está escuchando en 3000/3001/3002.

  - En Windows puedes encontrar el PID que usa el puerto y matarlo:
    ```powershell
    Get-NetTCPConnection -LocalPort 3000 | Select-Object -Property LocalAddress,LocalPort,State,OwningProcess
    taskkill /PID <pid> /F
    ```
  - Alternativa sencilla: cerrar las PowerShell/ventanas donde ya hayas arrancado `npm start` antes.

- Error en la consola del navegador: "Failed to find a valid digest in the 'integrity' attribute" o "L is not defined":
  - Si pasa, recarga sin caché (Ctrl+F5) o verifica que `gateway/public/index.html` no tenga atributos `integrity` incompatibles con el CDN. En este PoC ya se quitaron esos atributos para evitar bloqueos por mismatch.

Qué revisar si algo no funciona

- Asegúrate de que `npm install` corra sin errores en cada carpeta.
- Revisa los logs en la terminal donde ejecutaste `npm run dev` — `concurrently` te mostrará las salidas de cada servicio con un prefijo.

Notas técnicas y decisiones

- Visualización: usé Leaflet + OpenStreetMap (gratuito) para evitar necesitar keys.
- Gateway: `http-proxy-middleware` para reenviar rutas `/api/service-a` y `/api/service-b`.
- Comunicación entre servicios: Service A hace una petición HTTP a Service B (localhost:3002). Esto es intencional y sencillo para la PoC.

Ideas para siguientes pasos (si quieres seguir mejorando)

- Empaquetar todo con `docker-compose` para que sea aún más reproducible.
- Añadir una pequeña autenticación simulada en el Gateway (por ejemplo, un header) para demostrar políticas.
- Guardar logs o métricas básicas (contador de llamadas) en Service A.
- Reemplazar Leaflet por Google Maps (si necesitas capas/servicios premium), aunque eso requiere API key.

Si quieres, te dejo todo listo para levantar con docker-compose o te creo un `run-all.ps1` que abra 3 ventanas PowerShell separadas y lance los `npm start` — dime cuál prefieres y lo hago enseguida.

Listo, parcero: cualquier cosa me dices y lo ajustamos — si quieres que el README sea aún más formal lo dejo así, o lo corto y lo dejo tipo guía rápida.

- http://localhost:3001/call-b (service A que llama B)
- http://localhost:3002/info (service B)
- http://localhost:3002/data (service B datos)

Notas:

- El Gateway usa `http-proxy-middleware` para enrutar las rutas `/api/service-a` y `/api/service-b`.
- El frontend estático es simple y usa Tailwind CDN para estilo rápido.
