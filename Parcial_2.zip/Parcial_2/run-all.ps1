# run-all.ps1
# Script para Windows que abre 3 ventanas PowerShell y arranca service-b, service-a y gateway.
# Uso: Ejecutar este script desde la raíz del repo con permisos normales.

$base = Split-Path -Parent $MyInvocation.MyCommand.Definition

function Start-ServiceWindow($name, $path) {
    $absPath = Join-Path $base $path
    $installCmd = "if (-not (Test-Path (Join-Path '$absPath' 'node_modules'))) { npm install }"
    $cmd = "$installCmd; npm start"
    Write-Host "Abriendo ventana para $name en $absPath"
    Start-Process powershell -ArgumentList "-NoExit","-Command","cd '$absPath'; $cmd"
}

Start-ServiceWindow "service-b" "service-b"
Start-ServiceWindow "service-a" "service-a"
Start-ServiceWindow "gateway" "gateway"

Write-Host "Se abrieron ventanas para service-b, service-a y gateway. Revisa las consolas."