const express = require("express");
const app = express();
const PORT = process.env.PORT || 3002;

app.get("/info", (req, res) => {
  res.json({
    service: "B",
    message: "Hola desde Service B",
    timestamp: new Date().toISOString(),
    features: ["datos", "auth-simulado"],
  });
});

app.get("/data", (req, res) => {
  res.json({ items: [1, 2, 3, 4], generatedAt: new Date().toISOString() });
});

app.listen(PORT, () => {
  console.log(`Service B escuchando en http://localhost:${PORT}`);
});
