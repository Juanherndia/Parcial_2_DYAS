const express = require("express");
const fetch = require("node-fetch");
const cors = require("cors");
const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors());

app.get("/info", (req, res) => {
  res.json({
    service: "A",
    message: "Hola desde Service A",
    timestamp: new Date().toISOString(),
    features: ["proxy-to-b", "simple-metrics"],
  });
});

// Llama a Service B y devuelve los lugares enriquecidos
app.get("/call-b", async (req, res) => {
  try {
    const r = await fetch("http://localhost:3002/places");
    const b = await r.json();

    // ejemplo de enriquecimiento: calcular centroide de coordenadas
    const items = b.items || [];
    let lat = 0,
      lng = 0;
    items.forEach((p) => {
      lat += p.lat;
      lng += p.lng;
    });
    if (items.length > 0) {
      lat /= items.length;
      lng /= items.length;
    }

    res.json({
      service: "A",
      called: "B",
      placesCount: items.length,
      center: { lat, lng },
      places: items,
      timestamp: new Date().toISOString(),
    });
  } catch (err) {
    res.status(500).json({ error: String(err) });
  }
});

app.listen(PORT, () => {
  console.log(`Service A escuchando en http://localhost:${PORT}`);
});
