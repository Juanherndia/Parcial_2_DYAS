const out = document.getElementById("output");
const base = ""; // mismo host donde se sirva el gateway

function show(obj) {
  out.textContent = JSON.stringify(obj, null, 2);
}

document.getElementById("btnInfoA").addEventListener("click", async () => {
  show({ status: "cargando..." });
  const r = await fetch("/api/service-a/info");
  show(await r.json());
});

document.getElementById("btnCallB").addEventListener("click", async () => {
  show({ status: "service A llamando a B..." });
  const r = await fetch("/api/service-a/call-b");
  show(await r.json());
});

document.getElementById("btnDataB").addEventListener("click", async () => {
  show({ status: "pidiendo /data a service B..." });
  const r = await fetch("/api/service-b/data");
  show(await r.json());
});
