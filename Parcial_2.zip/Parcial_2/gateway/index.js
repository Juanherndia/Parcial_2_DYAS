const express = require("express");
const { createProxyMiddleware } = require("http-proxy-middleware");
const path = require("path");
const app = express();
const PORT = process.env.PORT || 3000;

// servir frontend estático
app.use("/", express.static(path.join(__dirname, "public")));

// proxies: exponer como /api/service-a/* y /api/service-b/*
app.use(
  "/api/service-a",
  createProxyMiddleware({
    target: "http://localhost:3001",
    changeOrigin: true,
    pathRewrite: { "^/api/service-a": "" },
  })
);
app.use(
  "/api/service-b",
  createProxyMiddleware({
    target: "http://localhost:3002",
    changeOrigin: true,
    pathRewrite: { "^/api/service-b": "" },
  })
);

app.listen(PORT, () =>
  console.log(`Gateway escuchando en http://localhost:${PORT}`)
);
