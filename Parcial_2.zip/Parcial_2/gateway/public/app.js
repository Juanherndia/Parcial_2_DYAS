const out = document.getElementById("output");
const map = L.map("map").setView([40.4168, -3.7038], 13);
L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
  maxZoom: 19,
  attribution: "&copy; OpenStreetMap contributors",
}).addTo(map);
let markers = [];

function show(obj) {
  out.textContent = JSON.stringify(obj, null, 2);
}

function clearMarkers() {
  markers.forEach((m) => map.removeLayer(m));
  markers = [];
}

function populateList(items) {
  const list = document.getElementById("placesList");
  list.innerHTML = "";
  items.forEach((p) => {
    const li = document.createElement("li");
    li.textContent =
      p.name + " (" + p.lat.toFixed(4) + ", " + p.lng.toFixed(4) + ")";
    li.addEventListener("click", () => {
      map.setView([p.lat, p.lng], 15);
    });
    list.appendChild(li);
  });
}

async function fetchJson(path) {
  show({ status: "cargando..." });
  const r = await fetch(path);
  return await r.json();
}

document.getElementById("btnInfoA").addEventListener("click", async () => {
  const j = await fetchJson("/api/service-a/info");
  show(j);
});

document.getElementById("btnCallB").addEventListener("click", async () => {
  const j = await fetchJson("/api/service-a/call-b");
  show(j);
  clearMarkers();
  if (j.places && j.places.length) {
    j.places.forEach((p) => {
      const m = L.marker([p.lat, p.lng])
        .addTo(map)
        .bindPopup(`<strong>${p.name}</strong><br/>id: ${p.id}`);
      markers.push(m);
    });
    if (j.center) map.setView([j.center.lat, j.center.lng], 14);
    populateList(j.places);
  }
});

document.getElementById("btnDataB").addEventListener("click", async () => {
  const j = await fetchJson("/api/service-b/places");
  show(j);
  clearMarkers();
  if (j.items && j.items.length) {
    j.items.forEach((p) => {
      const m = L.circleMarker([p.lat, p.lng], { radius: 8 })
        .addTo(map)
        .bindPopup(`<strong>${p.name}</strong><br/>id: ${p.id}`);
      markers.push(m);
    });
    const first = j.items[0];
    map.setView([first.lat, first.lng], 13);
    populateList(j.items);
  }
});
